# Whitaker Oasis — Full Quantity Takeoff (Reverse-Engineered)

**Source:** Apex Designer Pools estimate, 14x24 pool w/ spa, $116,955.18 job cost
**Purpose:** prove that every dollar line on the estimate has a derivable quantity behind it, and expose what's missing
**Status:** v1.0 — quantities derived from published construction standards, cross-checked against his dollars

---

## 0. Location: Lubbock, not DFW

This corrects v1.0, which assumed North Texas. **The Panhandle is a different problem, and two of my calls flip.**

Lubbock sits on the Southern High Plains, on **loamy eolian deposits of the Blackwater Draw Formation** — Amarillo-series fine sandy loam and related Olton/Pullman clay loams, not Blackland Prairie gumbo. Two facts drive everything:

**A calcic horizon — caliche — typically begins around 27 in and runs deep.** That is squarely inside pool-dig depth. A 5–6 ft excavation here goes through it, not around it.

**Mean annual precipitation is about 19 in.** Regional guidance describes Panhandle clay-loam subsoils as expansive but **moderated by low rainfall**, with the caliche layer complicating pier installation while **providing good bearing once reached**.

What flips:

| v1.0 said (DFW) | Lubbock reality |
|---|---|
| Pier / grade-beam contingency is a $3k–30k risk | **Downgraded.** Low rainfall moderates swell; caliche gives good bearing |
| Engineered low-PI select fill per TxDOT Item 132 | **Not the local issue.** That's a Blackland Prairie remedy |
| Excavation at $58/yd³ looked high | **Reversed.** Digging caliche justifies it, maybe more |
| Clay swell 35% for haul volume | **Corrected to ~25%** blended sandy loam over caliche |

Also in play, none of it on the estimate: **sustained High Plains wind** (raises gunite rebound and evaporation during cure), **hard freezes** at ~3,200 ft elevation (closed season for shooting gunite; freeze protection is standard scope), **high evaporative demand and hard Ogallala-sourced water** (affects fill, startup chemistry, and plaster), and a **much smaller sub pool** than DFW, which makes scheduling — not price — the binding constraint.

One upside: caliche is a saleable road-base material in the Panhandle. Spoil disposal may be cheaper here than a straight dump fee, and worth asking the excavation sub about.

---

## 1. Assumptions I had to make

The estimate gives only "14x24 Size Pool w/ Spa." Everything below flows from these. **Each one needs confirming — they move quantities materially.**

| Assumption | Value used | Why it matters |
|---|---|---|
| Pool shape | 14 × 24 rectangle | Auto cover requires rectangle, so this is near-certain |
| Depth profile | 3.5 ft → 6.0 ft, avg 4.75 ft | Drives excavation, gunite, plaster, water |
| Spa size | 7 × 7 × 3.5 ft deep | **Not stated anywhere.** Biggest single unknown |
| Shell thickness | 8 in floor and walls | Sources support 8 in floor typical, walls 6–10 in |
| Rebar schedule | #3 @ 12 in OC each way + 4× #4 bond beam | Industry standard |
| Equipment pad distance | 50 ft | "Long Plumb $3,000" line implies a long run |
| Deck area | not stated | The largest unquantified item on the sheet |

---

## 2. Geometry — everything derives from here

**Pool (14 × 24, avg depth 4.75 ft)**

| Measure | Value |
|---|---|
| Surface area | 336 sq ft |
| Perimeter | 76 LF |
| Floor area (along slope) | 338 sq ft |
| Wall area | 361 sq ft |
| Steps / bench | ~50 sq ft |
| **Pool wetted area** | **749 sq ft** |
| Water volume | 1,596 ft³ = **11,939 gal** |

**Spa (7 × 7 × 3.5 ft, assumed)**

| Measure | Value |
|---|---|
| Surface area | 49 sq ft |
| Perimeter | 28 LF |
| Floor + walls + seat | **172 sq ft** |
| Water volume | 171 ft³ = **1,283 gal** |

**Combined: 921 sq ft wetted area · 104 LF perimeter · 13,222 gallons**

---

## 3. The takeoff, by his cost codes

### 200 — Excavation

| Item | Qty | Unit | Basis |
|---|---|---|---|
| Dig footprint (pool) | 15.33 × 25.33 | ft | inside dims + 2× 8 in shell |
| Bank volume, pool | 78 | yd³ | 388 sq ft × 5.42 ft avg |
| Bank volume, spa | 11 | yd³ | |
| Bank + sloughing allowance (7%) | **95** | **yd³ bank** | |
| Loose volume after swell (~25% blended) | **119** | **yd³ loose** | sandy loam 10–20%, caliche 40–70% |
| Haul trucks @ 14 yd³ | **9** | loads | |
| Rebound haul-off (see §5) | 3–4 | yd³ | gunite sub's rebound is the builder's cost |

> **Check:** $5,500 ÷ 95 bank yd³ = **$58/yd³**. Generic excavation runs $7–15/yd³ — but that's soil, and roughly the bottom 3–4 ft of this dig is in **caliche** (see §0). Add precision shaping and access constraints and $58/yd³ is defensible, possibly light on a hard-caliche lot. **I flagged this as "high" in v1.0. That was wrong — it was a DFW read applied to a Panhandle job.**

### 300 — Pool Shell Construction (rebar)

| Item | Qty | Unit |
|---|---|---|
| #3 bar, shell grid @ 12 in OC each way | 1,800 | LF |
| + laps and waste (15%) | **2,070** | **LF** |
| #3 sticks @ 20 ft | 104 | ea |
| #4 bar, bond beam (4 continuous) | **458** | **LF** |
| #4 sticks @ 20 ft | 23 | ea |
| Steel weight, #3 (0.376 lb/ft) | 778 | lb |
| Steel weight, #4 (0.668 lb/ft) | 306 | lb |
| **Total steel** | **1,084 lb (0.54 ton)** | |
| Tie intersections | ~900 | ea |
| Tie wire, 16 ga | ~5 | lb |
| Dobies / chairs @ 1 per 4 sq ft | ~225 | ea |

> **Check:** steel material at ~$0.75/lb ≈ $813. His line is $4,000 for "Rebar / Rebar Labor," leaving ~$3,190 labor. Reasonable for a 2–3 man-day cage.
>
> **This is the rebar allocation basis.** 2,070 LF of #3 is what this job draws from the truckload — not a guess.

### 400 — Pool Shell Construction (gunite)

| Item | Qty | Unit |
|---|---|---|
| Shell volume @ 8 in over 921 sq ft | 22.7 | yd³ |
| Bond beam, 104 LF @ ~0.5 ft³/LF | 1.9 | yd³ |
| **In-place volume** | **24.6** | **yd³** |
| Rebound allowance (15% blended) | 3.7 | yd³ |
| **Ordered / paid volume** | **28.3** | **yd³** |

Rebound rates for dry-mix gunite run 5–15% on floors and 15–25% on walls and slopes.

> **Check:** $12,000 ÷ 28.3 yd³ = **$424/yd³ installed.** Published 2026 range is $350–600/yd³. **This validates cleanly.** His gunite number is well calibrated.

### 800 — Pool Finishes

| Item | Qty | Unit | Basis |
|---|---|---|---|
| Waterline tile, 6 in band | 52 | sq ft | 104 LF × 0.5 ft |
| + waste (15%) | **60** | **sq ft** | |
| Coping, pool + spa | 100 | LF | 76 + ~24 exposed |
| + waste (10%) | **110** | **LF** | |
| Plaster area | **921** | **sq ft** | wetted area |
| Plaster bags (80 lb, 22–25 sq ft/bag @ ⅜–½ in) | 40 | ea | |
| + waste (10%) | **44** | **bags** | |

> **Checks:**
> - Plaster material $3,750 ÷ 44 bags = **$85/bag**. Diamond Brite territory. ✓
> - Plaster labor $5,000 ÷ 921 sq ft = **$5.43/sq ft**. Reasonable. ✓
> - Tile material $1,950 ÷ 60 sq ft = **$32.50/sq ft** — high for standard tile. Either glass tile, or the spa is fully tiled and my 6 in band assumption is wrong. **Flag.**
> - Coping $7,550 ÷ 100 LF = **$75.50/LF** combined. Stone coping with auto-cover encapsulation — plausible.

**Correction to PRD 02:** my earlier back-of-envelope used 716 sq ft and produced $12.22/sq ft for plaster. The real wetted area including the spa and steps is 921 sq ft, giving $9.51/sq ft. My number was wrong by 28%. This is precisely why the takeoff has to be built from geometry rather than eyeballed.

### 700 — Pool Plumbing

2 in PVC is the current standard for new construction; 1.5 in is legacy.

| Item | Qty | Unit |
|---|---|---|
| Skimmer lines, 2 in (2 × 60 LF) | 120 | LF |
| Main drain, dual VGB-compliant, 2 in | 110 | LF |
| Return lines (4), 2 in trunk / 1.5 in eyeball | 220 | LF |
| Spa jet lines, 1.5 in (8 jets × ~20 LF) | 140 | LF |
| Spa suction + return, 2 in | 110 | LF |
| Spillway line | 55 | LF |
| **Total PVC** | **~755** | **LF** |
| Fittings @ ~1 per 9 LF | ~85 | ea |
| Primer + cement | 2–3 | gal |
| Jet T-bodies (his $300 line ÷ ~$30 ea) | **~10** | **ea** |

### 500 — Utilities / Bonding

Per NEC 680.26, the bonding conductor is **#8 AWG solid bare copper**, the perimeter surface bonded extends **3 ft horizontally** beyond the inside pool walls, and it must tie to the shell steel at **a minimum of four points** uniformly spaced.

| Item | Qty | Unit |
|---|---|---|
| #8 solid bare copper, perimeter loop (3 ft offset) | ~130 | LF |
| #8 jumpers to pump, heater, niches, rails, water bond | ~100 | LF |
| **Total #8 copper** | **~230** | **LF** |
| Listed bonding clamps | ~12 | ea |
| Rebar tie points (code minimum 4) | 4 | ea |

> **Check:** $250 for the Bonding line. 230 LF of #8 solid bare copper at $1.00–1.50/LF is **$230–345 in material alone**, before clamps or labor. **This line looks light.** Either bonding labor is buried inside the $3,000 Electrician line, or it's under-costed.

### 900 — Cover

Component list matches the standard encapsulated under-track system.

| Item | Qty | Unit |
|---|---|---|
| Track, both sides | ~52 | LF |
| Encapsulation extrusion (his "Gunite Encap Kit") | ~52 | LF |
| Cover fabric | ~364 | sq ft |
| Leading edge bar | 14 | LF |
| Drum, mechanism, ropes, pulleys, motor | 1 | set |
| Stone lid + SS lid brackets | ~14 | LF |
| Track splices | 0 | — (only needed over 44 ft/side) |

> The odd cents on "Gunite Encap Kit $1,130.18" — among round numbers everywhere else — means that line came off a real invoice. **The round numbers are rules of thumb; the odd ones are real.** That's the map for which unit costs are already trustworthy.

### 1000 — Pool Deck

| Item | Qty | Unit |
|---|---|---|
| Decorative concrete | **not stated** | sq ft |
| Turf | **not stated** | sq ft |

Back-solving: $5,000 at $12–18/sq ft implies **280–415 sq ft** of decorative concrete — a minimal 3–4 ft surround. But this is an allowance, not a takeoff. **Largest unquantified item on the sheet.**

### 300 — Pool Equipment

| Item | Qty / spec |
|---|---|
| Filter sand (24 in sand filter) | ~300 lb / 6 bags |
| Heater sizing basis | 13,222 gal; spa quick-heat drives the spec |
| Pump | Hayward VS950 Omni, 1 ea |
| UV filter, valves, fittings | per his list |

---

## 4. Unit costs derived (starting library)

| Cost code | Unit | Derived rate | Confidence |
|---|---|---|---|
| Gunite | $/yd³ paid | $424 | **High** — inside published range |
| Plaster material | $/bag | $85 | **High** |
| Plaster labor | $/sq ft | $5.43 | Medium |
| Rebar installed | $/lb steel | $3.69 | Medium — labor-heavy, not a material rate |
| Excavation | $/bank yd³ | $58 | **Low** — needs sub invoice |
| Tile material | $/sq ft | $32.50 | **Low** — scope unclear |
| Coping installed | $/LF | $75.50 | Medium |

**Do not treat these as the unit cost library.** They're one job, and the spa contaminates every line because it isn't dimensioned separately. This is the *method* validated, not the *numbers*. The library still needs 5–10 jobs per PRD 02, Milestone 1.

---

## 5. What's missing entirely

This is the more valuable half of the exercise. Every item below is standard scope for a DFW gunite pool and appears **nowhere** on the estimate.

**Serious — South Plains specific:**

1. **Caliche excavation contingency.** The single biggest cost variable on a Lubbock pool, and there's no allowance for it. Caliche depth and hardness vary lot to lot; a hard layer shallow in the profile can mean rock teeth, a hammer, or bigger iron. Under cost-plus this passes through — but only if the contract anticipates it and the customer was warned.
2. **Geotechnical / soil report.** No line item. Less about swell here than about **where the caliche starts and how hard it is** — which is an excavation-pricing question before it's a structural one.
3. **Structural engineering.** No line item.
4. **Gas line for the heater.** There's a $3,350 Hayward heater on this estimate and **no gas line, no meter upgrade, no utility coordination.** A heater that size frequently needs a new run. Real gap, not a rounding error.
5. **Freeze protection and seasonal scheduling.** Lubbock sits near 3,200 ft with genuine hard freezes. Gunite can't be shot in freezing weather, so the build calendar has a closed season — and freeze protection on equipment and exposed plumbing is standard scope, not an upgrade.

**Standard scope, also absent:**

6. **Permits — literally $0.00** with a live line item
7. **Water to fill** — 13,222 gallons, meter or truck
8. **Curing water** — shell must be kept moist 7–28 days
9. **Rebound haul-off** — the gunite sub's rebound is explicitly the builder's cost and cannot be back-charged as unused material
10. **Startup chemicals**
11. **Equipment pad slab**
12. **Deck drainage**
13. **Labor burden** — no line anywhere
14. **PM / supervision** — someone runs this for 6–8 weeks
15. **Warranty / callback reserve**

---

## 6. What this proves

**Every line on his estimate has a derivable quantity behind it.** Nothing here required guessing at method — only at dimensions he didn't record.

**His pricing instincts are better than the paperwork suggests.** Gunite at $424/yd³ and plaster at $85/bag both land inside published ranges. The numbers in his head are calibrated; they're just undocumented, untransferable, and unauditable.

**The gap is documentation, not competence.** On a cost-plus contract, "Rebar $4,000" is unsupportable. "2,070 LF of #3 at $X" is.

**The missing scope is the bigger financial risk than the pricing question.** Items 1–5 above are thousands to tens of thousands of dollars each, and under cost-plus they surface as change orders mid-build — which is exactly the conversation that costs a builder a referral.
